import java.util.Scanner;

public class Main {
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		
		MyGenerator my = new MyGenerator();
		String mypass = my.generate(8);
		PwdGenerator pg = new PwdGenerator();
		String s = pg.generatePassword(8);
		WordGenerator word = new WordGenerator();
		String generatedword = word.generate(3);
		UserGenerated ug = new UserGenerated();
		String u = ug.generate();
		SentenceGenerator sg = new SentenceGenerator();
	    String sentanceg = sg.generate();
	        
		my.print(mypass);
		pg.print(s);
		word.print(generatedword);
		ug.print(u);
		sg.print(sentanceg);
	        
		Anaylsis analyze = new Anaylsis();
		analyze.bestpass(mypass, s, generatedword,u,sentanceg);
				
		}
			
}



